#ifndef _ACTION_H_
#define _ACTION_H_

#include "common.h"
#include "probability.h"

class Action {

public:
	int myself;
	string action;
	ofstream fout;
	Probability* prob;
	map<int, INFO> person;
	vector<string> m_holdcards;

	Action(int myId, int hand);
	string getActionPreflop(int numUnfold, int maxBet, bool passive, bool firstBet);
	string getActionFlop(int totalBet);
	string getActionTurn(int totalBet);
	string getActionRiver(int totalBet);

private:
	string raiseBet(double ratio, int phrase);
	int MakeDecision(int numUnfold, int maxBet, bool passive, bool firstBet);
};

#endif
