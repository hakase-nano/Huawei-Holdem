#include "action.h"
using namespace std;

Action::Action(int myId, int hand) {
    myself = myId;
	prob = new Probability();
    if (PRINT) {
        fout.open("stat.txt", ios::app);
        fout << "\n!!!!!!!!!this is " << hand+1 << " hand " << endl;
    }
}

string Action::getActionPreflop(int numUnfold, int maxBet, bool passive, bool firstBet) {

    int ret = MakeDecision(numUnfold, maxBet, passive, firstBet);
    switch (ret) {
        case 0: return "fold \n";
        case 1: return "call \n";
        case 2: return "check \n";
        case 3: return "raise 100 \n";
        case 4: return "all_in \n";
        default : return "fold \n";
    }
}

/*
string Action::getActionFlop(int maxBet) {
    double ex = 0;
    double probs[10];
    prob->calculateProbForTypes(2, probs);
    for (int i=0; i<10; i++) {
        fout << i << " " << probs[i] << endl;
    }
    // calculate the exception
    for (int i=0; i<10; i++) {
        ex += weight[i]*probs[i];
    }
    fout << "ex is " << ex << endl;
    // determine the action
    if (ex >= 2.1) {
        action = "raise 200 \n";
    }
    else if (ex >= 1.5 ) {
        if (person[myself].diff != 0) {
            if (maxBet > person[myself].jetton / 2) action = "fold \n"; 
            else action = "call \n";
        }
        else action = "check \n";
    }
    else action = "fold \n";

   	return action;
}
*/
string Action::getActionFlop(int totalBet) {

    double winprob, tieprob;
    prob->calculateProb(2, winprob, tieprob, true);
    if (PRINT) fout << "winprob is " << winprob << " tieprob is " << tieprob << endl;

    if (winprob > 0.6) {
        if (person[myself].diff == 0) action = raiseBet(winprob, 2);
        else {
            double p = totalBet*1.0/(person[myself].diff);
            double ratio = (p*winprob + p/2*tieprob - (1-winprob-tieprob)) / p; 
            if (PRINT) fout << "ratio is " << ratio << endl;

            if (ratio >= PRATIO) { 
                action = raiseBet(winprob, 2);
            }
            else action = "fold \n";
        }
    }
    else {
        if (person[myself].diff == 0) action = "check \n";
        else if (person[myself].diff < person[myself].jetton/3 && winprob > 0.2) action = "call \n";
        else action = "fold \n";
    }

    return action;
}

string Action::getActionTurn(int totalBet) {

	double winprob, tieprob;
   	prob->calculateProb(3, winprob, tieprob, false);
    if (PRINT) fout << "winprob is " << winprob << " tieprob is " << tieprob << endl;

    if (winprob > 0.7) {
        if (person[myself].diff == 0) action = raiseBet(winprob, 3);
        else {
       	    double p = totalBet*1.0/(person[myself].diff);
            double ratio = (p*winprob + p/2*tieprob - (1-winprob-tieprob)) / p; 
            if (PRINT) fout << "ratio is " << ratio << endl;

            if (ratio >= PRATIO) { 
                action = raiseBet(winprob, 3);
            }
            else action = "fold \n";
        }
    }
    else {
        if (person[myself].diff == 0) action = "check \n";
        else if (person[myself].diff < person[myself].jetton/3 && winprob > 0.2) action = "call \n";
        else action = "fold \n";
    }

    return action;
}

string Action::getActionRiver(int totalBet) {

	double winprob, tieprob;
   	prob->calculateProb(4, winprob, tieprob, false);
    if (PRINT) fout << "winprob is " << winprob << " tieprob is " << tieprob << endl;

    if (winprob > 0.8) {
        if (person[myself].diff == 0) action = raiseBet(winprob, 4);
        else { 
           	double p = totalBet*1.0/(person[myself].diff);
            double ratio = (p*winprob + p/2*tieprob - (1-winprob-tieprob)) / p; 
            if (PRINT) fout << "ratio is " << ratio << endl;
                    
            if (ratio >= PRATIO) { 
                action = raiseBet(winprob, 4);
            }
            else action = "fold \n";
        }
    }
    else {
        if (person[myself].diff == 0) action = "check \n";
        else if (person[myself].diff < person[myself].jetton/3 && winprob > 0.5) action = "call \n";
        else action = "fold \n";
    }

    return action;
}

string Action::raiseBet(double ratio, int phrase) {

    int minRaise = person[myself].jetton;
    int maxbet = -1;
    for (map<int, INFO>::iterator it=person.begin(); it!=person.end(); it++) {
        if (it->first != myself && (maxbet == -1 || it->second.jetton + it->second.bet - person[myself].bet > maxbet)) 
            maxbet = it->second.jetton + it->second.bet - person[myself].bet;
    }
    if (maxbet < minRaise) minRaise = maxbet;

    int num = 11 - phrase;
    int money = static_cast<int>(pow(2,num*ratio)*1.0/(pow(2,num)-1)*minRaise/(5-phrase));
    if (person[myself].jetton <= money) return "all_in \n"; 
    if (money > BIGBLINDBET && money >= person[myself].diff) {
         int raise = money - person[myself].diff;
         stringstream ss;
         string str;
         ss << raise;
         ss >> str;
         if (raise) return "raise " + str + " \n";
         else {
            if (person[myself].diff) return "call \n";
            else return "check \n";
         }
    }
    else if (person[myself].jetton < 400 && ratio > (4+phrase)*0.1) {
        if (person[myself].diff > person[myself].jetton) return "all_in \n";
        else return "call \n";
    }
    return "fold \n";
}

int Action::MakeDecision(int numUnfold, int maxBet, bool passive, bool firstBet) {

    bool flag = false;
    string position = person[myself].position;
    bool sameColor = (m_holdcards[0] == m_holdcards[2]);

    // no raise, small blind, 2 person, diff == 0
    if (person[myself].sblindFlag == true && numUnfold == 2 && person[myself].diff == 0)
        return 2;
    // no raise, big blind do not fold 
    if(person[myself].bblindFlag == true && person[myself].diff == 0)
        return 2;

    // Early, Middle, Late
    string NiceCard1o[11][2] = {{"A","A"}, {"K","K"}, {"Q","Q"}, {"J","J"}, {"10","10"}, {"9","9"}, 
                                {"8","8"}, {"A","K"}, {"A","Q"}, {"A","J"}, {"K","Q"}};
    for (int i=0; i<11; i++) {
        if((m_holdcards[1] == NiceCard1o[i][0] && m_holdcards[3] == NiceCard1o[i][1])
            || (m_holdcards[3] == NiceCard1o[i][0] && m_holdcards[1] == NiceCard1o[i][1])) {
                flag = true;
                break;       
		}
    }
    string NiceCard1s[9][2] = {{"A","10"}, {"K","J"}, {"K","10"}, {"Q","J"}, {"Q","10"},
                               {"J","10"}, {"J","9"}, {"10","9"}, {"9","8"}};
    for (int i=0; i<9; i++) {
        if(sameColor && ((m_holdcards[1] == NiceCard1s[i][0] && m_holdcards[3] == NiceCard1s[i][1]) 
            || (m_holdcards[3] == NiceCard1s[i][0] && m_holdcards[1] == NiceCard1s[i][1]))) {
                flag = true;
                break;
		}
    }
    
    // Early && passive, Middle, Late
    if ((!position.compare("Early") && passive) || !position.compare("Middle") || !position.compare("Late")) { 
        string NiceCard2o[4][2] = {{"7","7"}, {"K","J"}, {"Q","J"}, {"J","10"}};
        for (int i=0; i<4; i++) {
            if ((m_holdcards[1] == NiceCard2o[i][0] && m_holdcards[3] == NiceCard2o[i][1]) 
                || (m_holdcards[3] == NiceCard2o[i][0] && m_holdcards[1] == NiceCard2o[i][1])) {
                    flag = true;
                    break;
			}
        }
        string NiceCard2s[13][2] = {{"A","9"}, {"A","8"}, {"A","7"}, {"A","6"}, {"A","5"}, {"A","4"}, 
                                    {"A","3"}, {"A","2"}, {"Q","9"}, {"10","8"}, {"9","7"}, {"8","7"}, {"7","6"}};
        for (int i=0; i<13; i++) {
            if(sameColor && ((m_holdcards[1] == NiceCard2s[i][0] && m_holdcards[3] == NiceCard2s[i][1]) 
                || (m_holdcards[3] == NiceCard2s[i][0] && m_holdcards[1] == NiceCard2s[i][1]))) {
                    flag = true;
                    break;
			}
        }
    }

    // Middle && passive, Late
    if ((!position.compare("Middle") && passive) || !position.compare("Late")) {
        string NiceCard3o[5][2] = {{"6","6"}, {"5","5"}, {"A","10"}, {"K","10"}, {"Q","10"}};
        for (int i=0; i<5; i++) {
            if((m_holdcards[1] == NiceCard3o[i][0] && m_holdcards[3] == NiceCard3o[i][1]) 
                || (m_holdcards[3] == NiceCard3o[i][0] && m_holdcards[1] == NiceCard3o[i][1])) {
                    flag = true;
                    break;
			}
        }
        string NiceCard3s[5][2] = {{"K","9"}, {"J","8"}, {"8","6"}, {"7","5"}, {"5","4"}};
        for (int i=0; i<5; i++) {
            if(sameColor && ((m_holdcards[1] == NiceCard3s[i][0] && m_holdcards[3] == NiceCard3s[i][1]) 
                || (m_holdcards[3] == NiceCard3s[i][0] && m_holdcards[1] == NiceCard3s[i][1]))) {
                    flag = true;
                    break;
			}
        }
    }

    // Late && firstBet
    if (!position.compare("Late") && firstBet) {
        string NiceCard4o[6][2] = {{"4","4"}, {"3","3"}, {"2","2"}, {"J","9"}, {"10","9"}, {"9","8"}};
        for (int i=0; i<6; i++) {
            if((m_holdcards[1] == NiceCard4o[i][0] && m_holdcards[3] == NiceCard4o[i][1]) 
                || (m_holdcards[3] == NiceCard4o[i][0] && m_holdcards[1] == NiceCard4o[i][1])) {
                    flag = true;
                    break;
			}
        }
        string NiceCard4s[12][2] = {{"K","8"}, {"K","7"}, {"K","6"}, {"K","5"}, {"K","4"}, {"K","3"}, 
                                    {"K","2"}, {"Q","8"}, {"10","7"}, {"6","4"}, {"5","3"}, {"4","3"}};
        for (int i=0; i<12; i++) {
            if(sameColor && ((m_holdcards[1] == NiceCard4s[i][0] && m_holdcards[3] == NiceCard4s[i][1]) 
                || (m_holdcards[3] == NiceCard4s[i][0] && m_holdcards[1] == NiceCard4s[i][1]))) {
                    flag = true;
                    break;
			}
		}
    }

    if (PRINT) fout << "flag is " << flag << endl;
    if (flag == true) {
        if (PRINT) fout << "diff is " << person[myself].diff << " bet is " << person[myself].bet << " maxBet is " << maxBet << " jetton is " << person[myself].jetton << endl;
        
        if (person[myself].jetton < 400) {
            if (person[myself].diff > person[myself].jetton) return 4;
            else return 1;
        }
        
        if (person[myself].diff == 0) return 2;   //check
        else if (maxBet <= person[myself].jetton*2 / 5) return 1;  //call
        else {
            string NiceCard[10][2] = {{"A","A"},{"K","K"},{"A","K"},{"Q","Q"},{"J","J"},
                                      {"9","9"},{"8","8"},{"A","Q"},{"7","7"},{"10","10"}};
            flag = false;
            for(int i = 0; i < 10; i++) {
                if((m_holdcards[1] == NiceCard[i][0] && m_holdcards[3] == NiceCard[i][1]) 
                    || (m_holdcards[3] == NiceCard[i][0] && m_holdcards[1] == NiceCard[i][1])) {
                        flag = true;
                        break;
                }
            }
            if (flag == true) return 1; // call
            else return 0; // fold
        }
    }
    else return 0; //fold
}
