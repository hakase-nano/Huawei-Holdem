#include "common.h"
#include "action.h"
using namespace std;

// card info
vector<string> myCards;
vector<string> publicCards;

// <id, person info> pair
map<int, INFO> person;

// hold'em info
int maxBet;
int totalBet;
int myself;
int phrase;
int hand;
int numUnfold;

// decision
Action* action;

int sockfd;
struct sockaddr_in serv_addr;
bool gameoverFlag;

// buffer
string strbuf;
int pbuffer, pebuffer;
char buffer[MAXSIZE];
char actionBuffer[MAXSIZE];

// output player's info
ofstream fout;


int turnCard(string c, string p) {
    int  point, x;
    for (int i=0; i<4; i++) {
        if (!c.compare(color[i])) {
            point = i;
            break;
        }
    }
    if (isdigit(p[0])) {
        x = 0;
        for (int i=0; i<p.size(); i++)
            x = x*10 + p[i]-'0';
        point += (x-1)*4;
    }
    else {
        if (!p.compare("J")) point += 40;
        else if (!p.compare("Q")) point += 44;
        else if (!p.compare("K")) point += 48; 
    }
    return point;
}

int getNum() {
    int num = -1;

    while (pbuffer<pebuffer && !isdigit(strbuf[pbuffer])) pbuffer++;
    while (pbuffer<pebuffer && isdigit(strbuf[pbuffer])) {
        if (num == -1) num = 0;
        num = num*10 + strbuf[pbuffer] - '0';
        pbuffer++;
    }
    return num;
}

/*
    flag = 0, [a-zA-Z0-9]
    flag = 1, [a-zA-Z]
    flag = 2, [A-Z]
*/
bool ismyalpha(char ch, int flag) {
    if (flag == 1) return (isalpha(ch) || ch=='-');
    if (flag == 2) return (ch>='A' && ch<='Z'); 
    return (isalpha(ch) || isdigit(ch));
}

string getString(int flag=1) {
    int index = 0;
    string msg;
    
    while (pbuffer<pebuffer && !ismyalpha(strbuf[pbuffer], flag)) pbuffer++;
    while (pbuffer<pebuffer && ismyalpha(strbuf[pbuffer], flag)) {
        msg += strbuf[pbuffer];
        pbuffer++;
    }
    return msg;
}

void processSeatInfo() {
    int times = 0;
    int pos = 1;

    // initial global variable
    person.clear();
    action = new Action(myself, hand); 
    maxBet = -1, phrase = 1, hand++, numUnfold = 0;
    
    // a new hand start
    if (PRINT) fout << "----hand " << hand << "----" << endl; 

    while (pbuffer < pebuffer) {
        int pid = getNum();
        int jetton = getNum();
        int money = getNum();

        if (pid != -1) {
            INFO info;
			info.lastAction = "";
            info.jetton = jetton, info.money = money, info.bet = 0, info.diff = 0;
			info.buttonFlag = false, info.sblindFlag = false, info.bblindFlag = false, info.foldFlag = false, info.all_inFlag = false;

            if (times == 0) info.buttonFlag = true;
            else if (times == 1) info.sblindFlag = true;
            else if (times == 2) info.bblindFlag = true;
            if (pos == 1 || pos == 8) info.position = "Late";
            else if (pos == 6 || pos == 7) info.position = "Middle";
            else info.position = "Early";
            
            pos++, times++, numUnfold++;
            person.insert(make_pair(pid, info));
            if (PRINT) fout << "pid is " << pid << " jetton is " << jetton << " money is " << money << endl;
        }      
    }
}

void processBlind() {
    while (pbuffer < pebuffer) {
        int pid = getNum();
        int bet = getNum();
        if (pid != -1) {
            person[pid].bet = bet;
            if (bet > maxBet) maxBet = bet;
            if (PRINT) fout << "pid is " << pid << " bet is " << bet << endl;
        }
    }
}

void processHoldCards() {
    int card, i = 0;
    myCards.clear();
    while (pbuffer < pebuffer) {
        string c = getString(2);
        string point = getString(0);
        if (c.size()) {
            action->m_holdcards.push_back(c);
            action->m_holdcards.push_back(point);
            card = turnCard(c, point);
            action->prob->holdCards[i++] = card;
            action->prob->pool[card] = true;
            if (PRINT) fout << "color is " << c << " point is " << point << endl;
        }
    }
}

void determineAction(bool passiveFlag, bool firstBetFlag, int totalBet) {
    string maction;
    
    // determine the current action
    /*
    if (myself < 8000) {
        if (person[myself].diff != 0) maction = "call \n";
        else maction = "check \n";
    }
    else 
    */
    if (numUnfold == 1) maction = "check \n";
    else {
        action->person.clear();
        action->person = person;
        if (PRINT) fout << "map" << endl;
        for (map<int, INFO>::iterator it=person.begin(); it!=person.end(); it++) {
            if (PRINT) fout << "bet " << it->second.bet << " jetton " << it->second.jetton << " diff " << it->second.diff << endl;  
        }
        if (PRINT) fout << "action->map" << endl;
        for (map<int, INFO>::iterator it=action->person.begin(); it!=action->person.end(); it++) {
            if (PRINT) fout << "bet " << it->second.bet << " jetton " << it->second.jetton << " diff " << it->second.diff << endl;  
        }
        if (phrase == 1) maction = action->getActionPreflop(numUnfold, maxBet, passiveFlag, firstBetFlag);
        else if (phrase == 2) maction = action->getActionFlop(totalBet);
        else if (phrase == 3) maction = action->getActionTurn(totalBet);
        else if (phrase == 4) maction = action->getActionRiver(totalBet);
    }
 
    // send the action to game server
    bzero(actionBuffer, MAXSIZE);
    for (int i=0; i<maction.size(); i++) {
        actionBuffer[i] = maction[i];
    }
    if (PRINT) fout << "actionbuffer is " << actionBuffer << endl;

    send(sockfd, actionBuffer, maction.size(), 0);
}

void processInquire() {
    int pid, jetton, money, bet;
    bool firstBetFlag = true;
    bool passiveFlag = true;
    string laction;

    while (pbuffer < pebuffer) {
        pid = getNum();
        jetton = getNum();
        money = getNum();
        bet = getNum();
        laction = getString();
        if (pid != -1) {
            if (jetton != -1) {
                if (bet > maxBet) maxBet = bet;
                if (laction == "fold") {
                    if (person[pid].foldFlag == false) {
                        person[pid].foldFlag = true;
                        numUnfold--;
                    }
                }
                if (laction == "all_in") {
                    person[pid].all_inFlag = true;
                }
                if (laction == "all_in" || laction == "raise") passiveFlag = false;
                if (laction != "fold" && laction !="blind") firstBetFlag = false;
                person[pid].bet = bet;
                person[pid].diff = maxBet - bet;
                person[pid].jetton = jetton;
                person[pid].money = money;
                person[pid].lastAction = laction;

                if (PRINT) fout << "pid is " << pid << " jetton is " << jetton << " money is " << money << " bet is " << bet << " action is " << laction << endl; 
            }
            else {
                totalBet = pid;
                if (PRINT) fout << "total bet is " << totalBet << endl;
            }
        }
    }
	person[myself].diff = maxBet - person[myself].bet;
    determineAction(passiveFlag, firstBetFlag, totalBet);
}

void processFlop() {

    int card, i = 0;
    publicCards.clear();
    while (pbuffer < pebuffer) {
        string c = getString(2);
        string point = getString(0);
        if (c.size()) {
            publicCards.push_back(c);
            publicCards.push_back(point);
            card = turnCard(c, point);
            action->prob->communityCard[i++] = card;
            action->prob->pool[card] = true;
            if (PRINT) fout << "color is " << c << " point is " << point << endl;
        }
    }
    phrase++;
}

void processTurn() {
    int card;
    while (pbuffer < pebuffer) {
        string c = getString(2);
        string point = getString(0);
        if (c.size()) {
            publicCards.push_back(c);
            publicCards.push_back(point);
            card = turnCard(c, point);
            action->prob->communityCard[3] = card;
            action->prob->pool[card] = true;
            if (PRINT) fout << "color is " << c << " point is " << point << endl;
        }
    }
    phrase++;
}

void processRiver() {
    int card;

    while (pbuffer < pebuffer) {
        string c = getString(2);
        string point = getString(0);
        if (c.size()) {
            publicCards.push_back(c);
            publicCards.push_back(point);
            card = turnCard(c, point);
            action->prob->communityCard[4] = card;
            action->prob->pool[card] = true;
            if (PRINT) fout << "color is " << c << " point is " << point << endl;
        }
    }
    phrase++;
}

void processShowDown() {
    string c, nut_hand, point;
    int i, times, pid, rank;

    for (int i=0; i<5; i++) {
        c = getString(2);
        point = getString(0);
        if (PRINT) fout << "color is " << c << " point is " << point << endl;
    }
    while (pbuffer < pebuffer) {
        rank = getNum();
        pid = getNum();
        c = getString(2);
        point = getString(0);
        c = getString(2);
        point = getString(0);
        nut_hand = getString(2);
        if (rank != -1) {
            if (PRINT) fout << "pid is " << pid << " nut_hand is " << nut_hand << endl;
        }
    }
}

void processPotWin() {
    int pid, num;

    while (pbuffer < pebuffer) { 
        pid = getNum();
        num = getNum();
        if (pid != -1) {
            if (PRINT) fout << "pid is " << pid << " num is " << num << endl;
        }
    }
}

void process() {
    pbuffer = 0;
    strbuf = buffer;
    string msg;

    while (1) {
        pebuffer = strbuf.size()-1;
        msg = getString();
        if (!msg.size()) break;
        if (PRINT) fout << "!!!!!!!!!!!!!msg is " << msg << endl;

        string tag = '/' + msg;
        pebuffer = strbuf.find(tag, pbuffer) + tag.size();
        
        if (!msg.compare("inquire")) processInquire();
        else if (!msg.compare("seat")) processSeatInfo();
        else if (!msg.compare("blind")) processBlind();
        else if (!msg.compare("hold")) processHoldCards();
        else if (!msg.compare("flop")) processFlop();
        else if (!msg.compare("turn")) processTurn();
        else if (!msg.compare("river")) processRiver();
        else if (!msg.compare("showdown")) processShowDown();
        else if (!msg.compare("pot-win")) processPotWin();
        else if (!msg.compare("game-over")) gameoverFlag = 1;
    }
}

void connectServer(char* serverip, int serverport, char* clientip, int clientport) {

    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        if (PRINT) fout << "socket failed!" << endl;
        exit(-1);
    }
    if (PRINT) fout << "sockfd success" << endl;

    int on = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (const char*)&on, sizeof(on));
    struct sockaddr_in cli_addr;
    bzero(&cli_addr, sizeof(struct sockaddr_in));
    cli_addr.sin_family = AF_INET;
    cli_addr.sin_addr.s_addr = inet_addr(clientip);
    cli_addr.sin_port = htons(clientport); 
    bind(sockfd, (struct sockaddr*)&cli_addr, sizeof(cli_addr));

    bzero(&serv_addr, sizeof(struct sockaddr_in));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = inet_addr(serverip);
    serv_addr.sin_port = htons(serverport);   

    while (1) {
        int flag = connect(sockfd, (struct sockaddr*)(&serv_addr),sizeof(struct sockaddr));
        if (flag == 0) break;
    }
    if (PRINT) fout << "connect success" << endl;
}

int main(int argc, char* argv[]) {
    
    // get server info
    char* serverip = argv[1];
    int serverport = atoi(argv[2]);
    char* clientip = argv[3];
    int clientport = atoi(argv[4]);
    string pid(argv[5]);
    myself = atoi(argv[5]);
    string pname = "DontHitFace";
    if (PRINT) fout.open(pid.c_str());

    // step 0 - connect to game server
    connectServer(serverip, serverport, clientip, clientport);
    
    // step 1 - register
    string msg_tmp = "reg: " + pid + " " + pname + " \n";
    char msg[MAXSIZE];
    bzero(msg, MAXSIZE);
    for (int i=0; i<msg_tmp.size(); i++) {
        msg[i] = msg_tmp[i];
    }
    if (PRINT) fout << msg << endl;
    send(sockfd, msg, msg_tmp.size(), 0);
    
    // step 2 - play hold'em
    gameoverFlag = 0;
    hand = 0;
    while (!gameoverFlag) {
        bzero(buffer, MAXSIZE);
        recv(sockfd, buffer, MAXSIZE, 0);
        if (PRINT) fout << buffer << endl << endl;
        process();
    }
    
    // step 3 - disconnet to game server
    close(sockfd);

    return 0;
}
